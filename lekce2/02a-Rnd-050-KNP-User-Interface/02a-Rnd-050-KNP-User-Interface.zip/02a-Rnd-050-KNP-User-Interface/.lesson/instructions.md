# KNP - uživatelské rozhraní

Napište program, který vyzve uživatele, aby zvolil figuru (stiskem klávesy k/n/p) a vypíše název zvolené figury.

_Zkuste použít Console.ReadKey() místo Console.ReadLine()_