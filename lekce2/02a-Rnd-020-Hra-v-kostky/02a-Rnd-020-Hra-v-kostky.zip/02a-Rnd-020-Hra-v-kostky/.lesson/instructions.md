# Hra v kostky

Napište program, který si hodí 6-ti stěnnou kostkou, vyzve uživatele „hoď si“, počká, až stiskne klávesu, hodí mu také náhodné číslo a pak vypíše výsledek. 

Např.:
* `3:2 (Prohrál jsi)`
* `4:6 (Vyhrál jsi)`
* `3:3 (Remíza)`

Pokud nevíte, jak čekat na klávesu, pomůže vám zavolání metody `Console.ReadKey()`.