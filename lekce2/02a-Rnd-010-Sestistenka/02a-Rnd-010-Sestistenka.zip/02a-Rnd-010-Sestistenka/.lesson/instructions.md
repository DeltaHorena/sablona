# Šestistěnná kostka

Napište program, který si hodí 6-ti stěnnou kostkou a výsledek vypíše uživateli.

(Pokud netušíte, jak na to, návod najdete na https://student.delta-studenti.cz/mod/page/view.php?id=48048)