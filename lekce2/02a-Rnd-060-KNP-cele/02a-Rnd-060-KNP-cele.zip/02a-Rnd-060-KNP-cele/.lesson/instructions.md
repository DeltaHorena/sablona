# KNP - dohromady

Je čas napsat svou první skutečnou hru

Použijte předchozí dva programy k tomu, abyste vytvořili nový, který si vybere svoji figuru, pak se zeptá na figuru uživatele a vydá výsledek: Výhra/Prohra/Remíza.

Pokud chcete, aby program běžel donekonečna, zabalte ho do cyklu while:

```
while(true)
{
    // váš kód …
    // váš kód …
    // váš kód …
    // váš kód …
}
```

Program pak ukončí jen stisk `CTRL-C`

## Level 2 - KNP s pamětí
Pokud jste použili syčku while, změňte chování programu tak, aby si pamatoval, kolikrát uživatel dal kterou figuru a hrál podle toho (např. když zjistím, že nejčastější hráčova figura je papír, zahraju nůžky, pokud jsou papír a kámen stejně časté, vyberu papír, protože tak neprohraju, ale můžu vyhrát atd.). Počítejte a vypisujte také celkové skore - kolikrát kdo vyhrál.