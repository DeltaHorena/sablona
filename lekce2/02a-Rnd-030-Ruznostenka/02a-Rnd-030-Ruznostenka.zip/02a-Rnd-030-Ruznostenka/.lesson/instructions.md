# „Různostěnka“

Házecí kostka nemusí být pouze 6-stěnná. V různých hrách se používají i více-stěnné „kostky“. 

Napište program, který se zeptá, kolik stěn „kostka“ má, pak si s touto „kostkou“ 3× hodí a vypíše výsledek každého hodu a průměrnou hodnotu hodu.

Komunikace bude vypadat asi takto:

```
PC: Kolik stěn má kostka?
User: 10

PC: 1. hod: 10
PC: 2. hod: 7
PC: 3. hod: 6

PC: Průměrný hod: 7,67
```