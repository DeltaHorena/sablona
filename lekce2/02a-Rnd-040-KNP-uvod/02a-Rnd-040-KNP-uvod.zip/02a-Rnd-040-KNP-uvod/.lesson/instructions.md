# KNP - úvod

Napište program, který náhodně vybere jednu z figur "Kámen", "Nůžky", "Papír" a vypíše ji do konzole.